"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/publish-scheduled-posts.ts
var publish_scheduled_posts_exports = {};
__export(publish_scheduled_posts_exports, {
  config: () => config,
  default: () => handler
});
module.exports = __toCommonJS(publish_scheduled_posts_exports);
var import_app = require("firebase-admin/app");
var import_firestore = require("firebase-admin/firestore");

// lib/social-publisher.ts
async function publishToFacebook(post, tokens) {
  const { facebookPageId, facebookPageAccessToken } = tokens;
  if (!facebookPageId || !facebookPageAccessToken) {
    return { success: false, error: "Tokens Facebook manquants dans les param\xE8tres" };
  }
  try {
    let url;
    let body;
    if (post.mediaUrl && post.mediaType === "image") {
      const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "";
      const imageUrl = post.mediaUrl.startsWith("http") ? post.mediaUrl : `${siteUrl}${post.mediaUrl}`;
      url = `https://graph.facebook.com/v19.0/${facebookPageId}/photos`;
      body = {
        url: imageUrl,
        message: post.content,
        access_token: facebookPageAccessToken
      };
    } else if (post.mediaUrl && post.mediaType === "video") {
      const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "";
      const videoUrl = post.mediaUrl.startsWith("http") ? post.mediaUrl : `${siteUrl}${post.mediaUrl}`;
      url = `https://graph.facebook.com/v19.0/${facebookPageId}/videos`;
      body = {
        file_url: videoUrl,
        description: post.content,
        access_token: facebookPageAccessToken
      };
    } else {
      url = `https://graph.facebook.com/v19.0/${facebookPageId}/feed`;
      body = {
        message: post.content,
        access_token: facebookPageAccessToken
      };
    }
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    if (!res.ok || data.error) {
      return {
        success: false,
        error: data.error?.message ?? `Erreur HTTP ${res.status}`
      };
    }
    return { success: true, postId: data.id ?? data.post_id };
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : "Erreur inconnue Facebook"
    };
  }
}
async function publishToInstagram(post, tokens) {
  const { instagramBusinessAccountId, facebookPageAccessToken } = tokens;
  if (!instagramBusinessAccountId || !facebookPageAccessToken) {
    return { success: false, error: "Tokens Instagram manquants dans les param\xE8tres" };
  }
  if (!post.mediaUrl || post.mediaType !== "image") {
    return {
      success: false,
      error: "Instagram requiert une image. Les posts texte seul ne sont pas support\xE9s."
    };
  }
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "";
  const imageUrl = post.mediaUrl.startsWith("http") ? post.mediaUrl : `${siteUrl}${post.mediaUrl}`;
  try {
    const createRes = await fetch(
      `https://graph.facebook.com/v19.0/${instagramBusinessAccountId}/media`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          image_url: imageUrl,
          caption: post.content,
          access_token: facebookPageAccessToken
        })
      }
    );
    const createData = await createRes.json();
    if (!createRes.ok || createData.error) {
      return {
        success: false,
        error: createData.error?.message ?? `Erreur cr\xE9ation media Instagram (${createRes.status})`
      };
    }
    const creationId = createData.id;
    const publishRes = await fetch(
      `https://graph.facebook.com/v19.0/${instagramBusinessAccountId}/media_publish`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          creation_id: creationId,
          access_token: facebookPageAccessToken
        })
      }
    );
    const publishData = await publishRes.json();
    if (!publishRes.ok || publishData.error) {
      return {
        success: false,
        error: publishData.error?.message ?? `Erreur publication Instagram (${publishRes.status})`
      };
    }
    return { success: true, postId: publishData.id };
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : "Erreur inconnue Instagram"
    };
  }
}
async function publishToLinkedIn(post, tokens) {
  const { linkedinAccessToken, linkedinOrganizationId } = tokens;
  if (!linkedinAccessToken || !linkedinOrganizationId) {
    return { success: false, error: "Tokens LinkedIn manquants dans les param\xE8tres" };
  }
  const authorUrn = `urn:li:organization:${linkedinOrganizationId}`;
  const headers = {
    Authorization: `Bearer ${linkedinAccessToken}`,
    "Content-Type": "application/json",
    "X-Restli-Protocol-Version": "2.0.0"
  };
  try {
    let mediaCategory = "NONE";
    let mediaArray = [];
    if (post.mediaUrl && post.mediaType === "image") {
      const registerRes = await fetch(
        "https://api.linkedin.com/v2/assets?action=registerUpload",
        {
          method: "POST",
          headers,
          body: JSON.stringify({
            registerUploadRequest: {
              recipes: ["urn:li:digitalmediaRecipe:feedshare-image"],
              owner: authorUrn,
              serviceRelationships: [
                {
                  relationshipType: "OWNER",
                  identifier: "urn:li:userGeneratedContent"
                }
              ]
            }
          })
        }
      );
      const registerData = await registerRes.json();
      if (!registerRes.ok) {
        return {
          success: false,
          error: `Erreur enregistrement image LinkedIn (${registerRes.status})`
        };
      }
      const uploadUrl = registerData.value?.uploadMechanism?.["com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest"]?.uploadUrl;
      const assetUrn = registerData.value?.asset;
      if (!uploadUrl || !assetUrn) {
        return { success: false, error: "URL upload LinkedIn non trouv\xE9e" };
      }
      const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "";
      const imageUrl = post.mediaUrl.startsWith("http") ? post.mediaUrl : `${siteUrl}${post.mediaUrl}`;
      const imageRes = await fetch(imageUrl);
      const imageBuffer = await imageRes.arrayBuffer();
      const uploadRes = await fetch(uploadUrl, {
        method: "PUT",
        headers: { Authorization: `Bearer ${linkedinAccessToken}` },
        body: imageBuffer
      });
      if (!uploadRes.ok) {
        return { success: false, error: `Erreur upload image LinkedIn (${uploadRes.status})` };
      }
      mediaCategory = "IMAGE";
      mediaArray = [
        {
          status: "READY",
          description: { text: post.content.slice(0, 200) },
          media: assetUrn,
          title: { text: "Image" }
        }
      ];
    }
    const postBody = {
      author: authorUrn,
      lifecycleState: "PUBLISHED",
      specificContent: {
        "com.linkedin.ugc.ShareContent": {
          shareCommentary: { text: post.content },
          shareMediaCategory: mediaCategory,
          ...mediaArray.length > 0 ? { media: mediaArray } : {}
        }
      },
      visibility: {
        "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"
      }
    };
    const postRes = await fetch("https://api.linkedin.com/v2/ugcPosts", {
      method: "POST",
      headers,
      body: JSON.stringify(postBody)
    });
    const postData = await postRes.json();
    if (!postRes.ok) {
      return {
        success: false,
        error: postData.message ?? `Erreur publication LinkedIn (${postRes.status})`
      };
    }
    return { success: true, postId: postData.id };
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : "Erreur inconnue LinkedIn"
    };
  }
}
async function publishPost(post, tokens) {
  const tasks = [];
  if (post.platforms.includes("facebook")) {
    tasks.push(
      publishToFacebook(post, tokens).then((r) => ["facebook", r])
    );
  }
  if (post.platforms.includes("instagram")) {
    tasks.push(
      publishToInstagram(post, tokens).then((r) => ["instagram", r])
    );
  }
  if (post.platforms.includes("linkedin")) {
    tasks.push(
      publishToLinkedIn(post, tokens).then((r) => ["linkedin", r])
    );
  }
  const settled = await Promise.allSettled(tasks);
  let facebook;
  let instagram;
  let linkedin;
  for (const outcome of settled) {
    if (outcome.status === "fulfilled") {
      const [platform, result] = outcome.value;
      if (platform === "facebook") facebook = result;
      else if (platform === "instagram") instagram = result;
      else if (platform === "linkedin") linkedin = result;
    }
  }
  const values = [facebook, instagram, linkedin].filter(
    (v) => v !== void 0
  );
  const allSuccess = values.length > 0 && values.every((v) => v.success);
  const allFailed = values.length > 0 && values.every((v) => !v.success);
  const status = allSuccess ? "published" : allFailed ? "failed" : "partial";
  return { facebook, instagram, linkedin, status };
}

// netlify/functions/publish-scheduled-posts.ts
function getDb() {
  if (!(0, import_app.getApps)().length) {
    (0, import_app.initializeApp)({
      credential: (0, import_app.cert)({
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n")
      })
    });
  }
  return (0, import_firestore.getFirestore)();
}
async function getSiteTokens() {
  return {
    facebookPageId: process.env.FACEBOOK_PAGE_ID ?? "",
    facebookPageAccessToken: process.env.FACEBOOK_PAGE_ACCESS_TOKEN ?? "",
    instagramBusinessAccountId: process.env.INSTAGRAM_BUSINESS_ACCOUNT_ID ?? "",
    linkedinAccessToken: process.env.LINKEDIN_ACCESS_TOKEN ?? "",
    linkedinOrganizationId: process.env.LINKEDIN_ORGANIZATION_ID ?? ""
  };
}
async function handler() {
  console.log("[publish-scheduled-posts] Starting scheduled run...");
  try {
    const db = getDb();
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const snap = await db.collection("social-posts").where("status", "==", "scheduled").where("scheduledAt", "<=", now).get();
    if (snap.empty) {
      console.log("[publish-scheduled-posts] No due posts found.");
      return new Response("No due posts", { status: 200 });
    }
    const posts = snap.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    console.log(`[publish-scheduled-posts] Found ${posts.length} due post(s).`);
    const tokens = await getSiteTokens();
    for (const post of posts) {
      try {
        console.log(`[publish-scheduled-posts] Publishing post ${post.id}...`);
        const results = await publishPost(post, tokens);
        await db.collection("social-posts").doc(post.id).set(
          {
            status: results.status,
            publishedAt: results.status !== "failed" ? (/* @__PURE__ */ new Date()).toISOString() : null,
            platformResults: {
              ...results.facebook ? { facebook: results.facebook } : {},
              ...results.instagram ? { instagram: results.instagram } : {},
              ...results.linkedin ? { linkedin: results.linkedin } : {}
            },
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          },
          { merge: true }
        );
        console.log(`[publish-scheduled-posts] Post ${post.id} \u2192 ${results.status}`);
      } catch (err) {
        console.error(`[publish-scheduled-posts] Error publishing post ${post.id}:`, err);
        await db.collection("social-posts").doc(post.id).set(
          { status: "failed", updatedAt: (/* @__PURE__ */ new Date()).toISOString() },
          { merge: true }
        );
      }
    }
    return new Response(`Published ${posts.length} post(s)`, { status: 200 });
  } catch (err) {
    console.error("[publish-scheduled-posts] Fatal error:", err);
    return new Response("Internal error", { status: 500 });
  }
}
var config = {
  schedule: "*/15 * * * *"
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
